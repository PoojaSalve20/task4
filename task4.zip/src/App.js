import React, { Component } from "react";
import "./styles.css";

class Stockstuff extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      items: []
    };
  }

  componentDidMount() {
    fetch(
      "https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=IBM&interval=5min&apikey=demo"
    )
      .then(res => res.json())
      .then(
        result => {
          this.setState({
            isLoaded: true,
            items: Object.entries(result["Time Series (5min)"])
          });
        },
        error => {
          this.setState({
            isLoaded: true,
            error: true
          });
        }
      );
  }

  render() {
    const { error, isLoaded, items } = this.state;
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        
        <table>
          <tr>
              <th>Date Time</th>
              <th>Open</th>
              <th>high</th>
              <th>low</th>
              <th>close</th>
              <th>volume</th>
          </tr>
          {items.map(([date, item]) => (
          <tr key={date}>
          
    <td>{date}</td>
    <td>{item["1. open"]} </td>
    <td>{item["2. high"]}</td>
    <td>{item["3. low"]}</td>
    <td>{item["4. close"]}</td>
    <td>{item["5. volume"]}</td>
  </tr>    
  ))}
          </table>
        
      );
    }
  }
}

export default function App() {
  return (
    <div className="App">
      <Stockstuff />
    </div>
  );
}
